import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Employe from "./pages/Employe";
import EmployeOrdre from "./pages/EmployeOrdre";
import Projet from "./pages/Projet";
import ProjetOrdre from "./pages/ProjetOrdre";
import DepartementMc from "./pages/DepartementMc";
import Saisie from "./pages/Saisie";
import "./App.css";

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/" exact component={Employe} />
        <Route path="/employeOrdre" exact component={EmployeOrdre} />
        <Route path="/projet" exact component={Projet} />
        <Route path="/projetOrdre" exact component={ProjetOrdre} />
        <Route path="/departementMc" exact component={DepartementMc} />
        <Route path="/saisie" exact component={Saisie} />
      </Switch>
    </BrowserRouter>
  );
};

export default App;
