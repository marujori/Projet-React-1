import React, { useState, useEffect } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import AllProjet from "../components/AllProjet";

const All = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    axios
      .get("http://localhost:3006/projet?_sort=duree&_order=desc")
      .then((res) => setData(res.data));
  };

  return (
    <div className="affichage">
      <Logo />
      <Navigation />
      <h1> below the list of all movies</h1>
      {data.map((m) => (
        <AllProjet All={m} key={m.id} /> //c'est sa un props girl , il est créer dans movie.js et se fait call ici
      ))}
      <Footer />
    </div>
  );
};

export default All;
