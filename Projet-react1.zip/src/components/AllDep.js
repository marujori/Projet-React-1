import React from "react";

const AllDep = (props) => {
  const { All } = props;

  return (
    <div className="employe_card" id="bright">
      <div className="info-section">
        <div className="employe_header">
          <h2>{All.nom} </h2>
        </div>
      </div>
      <div></div>
    </div>
  );
};

export default AllDep;
