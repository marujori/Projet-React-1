import React from "react";

const Footer = () => {
  return (
    <div className="footer">
      <h2>CECI EST UN FOOTER</h2>
    </div>
  );
};

export default Footer;
