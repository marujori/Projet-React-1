import React from "react";
import { NavLink } from "react-router-dom";

const Navigation = () => {
  return (
    <div className="navigation">
      <NavLink exact to="/" activeClassName="nav-active">
        tous les employés
      </NavLink>
      <NavLink exact to="/projet" activeClassName="nav-active">
        tous les projets
      </NavLink>
      <NavLink exact to="/saisie" activeClassName="nav-active">
        Rajouter un projet
      </NavLink>
      <NavLink exact to="/employeOrdre" activeClassName="nav-active">
        Employés en ordre
      </NavLink>
      <NavLink exact to="/projetOrdre" activeClassName="nav-active">
        Projet en ordre
      </NavLink>
      <NavLink exact to="/departementMc" activeClassName="nav-active">
        Rechercher un département
      </NavLink>
    </div>
  );
};

export default Navigation;
