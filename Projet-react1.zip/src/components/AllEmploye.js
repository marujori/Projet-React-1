import React from "react";

const AllEmploye = (props) => {
  const { All } = props;

  return (
    <div className="employe_card" id="bright">
      <div className="info-section">
        <div className="employe_header">
          <h2>{All.nomComplet} </h2>
          <h3> Ville: {All.ville} </h3>
          <h3> Courriel : {All.courriel} </h3>
          <h3> probation: {All.probation} </h3>
          <h3> telephone : {All.telehphone} </h3>
          <h3> salaire : {All.salaire} </h3>
          <h3> departementId : {All.departementId} </h3>
          <h3> ProjetId : {All.projetId} </h3>
        </div>
      </div>
      <div></div>
    </div>
  );
};

export default AllEmploye;
