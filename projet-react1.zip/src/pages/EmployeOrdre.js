import React, { useState, useEffect } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import AllEmploye from "../components/AllEmploye";

const All = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    getData();
  }, [filter]);

  const getData = () => {
    axios
      .get(`http://localhost:3006/employe?_sort=salaire&_order=${filter}`)
      .then((res) => setData(res.data));
  };

  const onChangeValue = (e) => {
    setFilter(e.target.value);
  };

  return (
    <div className="affichage">
      <Logo />
      <Navigation />
      <div className="sort-container" onChange={onChangeValue}>
        <input type="radio" value="asc" name="filter" />
        croissant
        <input type="radio" value="desc" name="filter" />
        Décroissant
      </div>
      <div className="cancel">
        {filter && (
          <button onClick={() => setFilter("")}>Cancel sorting</button>
        )}
      </div>

      {filter ? (
        <ul>
          {data.map((m) => (
            <AllEmploye All={m} key={m.id} /> //c'est sa un props girl , il est créer dans movie.js et se fait call ici
          ))}
        </ul>
      ) : (
        <h1>appliquer filtre</h1>
      )}

      <Footer />
    </div>
  );
};

export default All;
