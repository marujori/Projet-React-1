import React, { useState } from "react";
import Navigation from "../components/Navigation";
import Logo from "../components/Logo";
import Footer from "../components/Footer";
import axios from "axios";

const Saisie = () => {
  const [newNom, setNewNom] = useState("");
  const [newBudget, setNewBudget] = useState();
  const [newDuree, setNewDuree] = useState("");

  const addNewNote = (e) => {
    e.preventDefault();
    axios.post("http://localhost:3006/projet", {
      nom: newNom,
      budget: newBudget,
      duree: newDuree,
    });
    window.alert("projet ajouté.");
  };

  return (
    <div className="saisie">
      <Logo />
      <Navigation />
      <h3>Ajouter un Projet</h3>
      <form onSubmit={(e) => addNewNote(e)}>
        <input
          type="text"
          placeholder="Nom du projet"
          value={newNom}
          onChange={(e) => setNewNom(e.target.value)}
        />
        <input
          type="text"
          placeholder="Budget souhaité"
          value={newBudget}
          onChange={(e) => setNewBudget(e.target.value)}
        />
        <input
          type="text"
          placeholder="Durée estimé"
          value={newDuree}
          onChange={(e) => setNewDuree(e.target.value)}
        />
        <input type="submit" value="Ajouter" />
      </form>
      <Footer />
    </div>
  );
};

export default Saisie;
