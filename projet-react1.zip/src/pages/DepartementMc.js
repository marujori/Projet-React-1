import React, { useState, useEffect } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import AllDep from "../components/AllDep";

const Search = () => {
  const [data, setData] = useState([]);
  const [motCle, setMotCle] = useState("");

  useEffect(() => {
    axios.get(`http://localhost:3006/departement?q=${motCle}`).then((res) => {
      setData(res.data);
    });
  }, [motCle]);

  const onSearch = (e) => {
    setMotCle(e.target.value);
  };

  return (
    <div className="searchMovie">
      <Logo />
      <Navigation />
      <div className="input-container">
        <input className="input" placeholder="Keyword" onChange={onSearch} />
      </div>

      {motCle ? (
        <ul>
          {data.map((m) => (
            <AllDep All={m} key={m.id} />
          ))}
        </ul>
      ) : (
        <div className="placeholder-container">
          <h1>Entrer un mot clé</h1>
        </div>
      )}
      <Footer />
    </div>
  );
};

export default Search;
