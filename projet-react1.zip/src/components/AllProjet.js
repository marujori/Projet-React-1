import React from "react";

const AllProjet = (props) => {
  const { All } = props;

  return (
    <div className="employe_card" id="bright">
      <div className="info-section">
        <div className="employe_header">
          <h2>{All.nom} </h2>
          <h3> release date : {All.budget} </h3>
          <h3> release date : {All.duree} </h3>
        </div>
      </div>
      <div></div>
    </div>
  );
};

export default AllProjet;
